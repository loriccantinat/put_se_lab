package put.io.patterns.implement;

public class MonitorRunner {

    public static void main(String args[]){
        SystemMonitor monitor = new SystemMonitor();
        //we create the new observer
        SystemInfoObserver infoObserver = new SystemInfoObserver();
        //we add the new observer to the list
        monitor.addSystemStateObserver(infoObserver);

        //now  we can add the remaining observers (garbage collector and cooler)
        GarbageCollectorObserver gcObserver = new GarbageCollectorObserver();
        monitor.addSystemStateObserver(gcObserver);

        CoolerObserver cObserver = new CoolerObserver();
        monitor.addSystemStateObserver(cObserver);

        while (true) {

            monitor.probe();

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
