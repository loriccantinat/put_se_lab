package put.io.patterns.implement;

import oshi.SystemInfo;
import oshi.hardware.*;
import oshi.software.os.OperatingSystem;

import java.util.ArrayList;
import java.util.List;

public class SystemMonitor {

    //we add the list of observers
    private List<SystemStateObserver> observers = new ArrayList<SystemStateObserver>();
    private SystemInfo si;

    private HardwareAbstractionLayer hal;

    private OperatingSystem os;

    private SystemState lastSystemState = null;

    private CentralProcessor cpu;

    private long[] prevTicks;

    public SystemMonitor(){
        si = new SystemInfo();
        hal = si.getHardware();
        os = si.getOperatingSystem();
        cpu = hal.getProcessor();
        prevTicks = cpu.getSystemCpuLoadTicks();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    //gestion functions
    public void addSystemStateObserver(SystemStateObserver observer){
        this.observers.add(observer); //we add the observer in parameter to the list

    }
    public void removeSystemStateObserver(SystemStateObserver observer) {
        this.observers.remove(observer); //we remove the observer in parameter from the list
    }

    //the notification function
    public void notifyObservers(){
        for(SystemStateObserver observer : this.observers){
            observer.update(this);
        }
    }


    public void probe(){
        // Get current state of the system resources
        double cpuLoad = cpu.getSystemCpuLoadBetweenTicks( prevTicks ) * 100;
        prevTicks = cpu.getSystemCpuLoadTicks();
        double cpuTemp = hal.getSensors().getCpuTemperature();
        double memory = hal.getMemory().getAvailable() / 1000000;
        int usbDevices = hal.getUsbDevices(false).size();

        lastSystemState = new SystemState(cpuLoad, cpuTemp, memory, usbDevices);

//        // Print information to the console
//        System.out.println("============================================");
//        System.out.println(String.format("CPU Load: %2.2f%%", lastSystemState.getCpu()));
//        System.out.println(String.format("CPU temperature: %.2f C", lastSystemState.getCpuTemp()));
//        System.out.println(String.format("Available memory: %.2f MB", lastSystemState.getAvailableMemory()));
//        System.out.println(String.format("USB devices: %d", lastSystemState.getUsbDevices()));
//
//        // Run garbage collector when out of memory
//        if (lastSystemState.getAvailableMemory() < 200.00){
//            System.out.println("> Running garbage collector...");
//        }
//
//        // Increase CPU cooling if the temperature is to high
//        if (lastSystemState.getCpuTemp() > 60.00){
//            System.out.println("> Increasing cooling of the CPU...");
//        }

        //we delete all print, we juste notify the observers
        notifyObservers();
    }

    public SystemState getLastSystemState() {
        return lastSystemState;
    }
}
